import pickle
import pymongo
from datetime import datetime

def gettime(time):
	try:
		return datetime.strptime(time, "%Y-%m-%d %H:%M UTC")
	except Exception as e:
		return None

conn = pymongo.MongoClient()
db = conn.test_database
PHP = db.PHP

f = open("C:\Users\Hao He\Desktop\data.pkl", "r")
datas = pickle.load(f)
error = []

for i in datas[1:]:
	try:
		PHP.insert({
			"ID#": int(i[0]),
			"Date": gettime(i[1]),
			"Last Modified": gettime(i[2]),
			"Package": i[3],
			"Type": i[4],
			"Status": i[5],
			"PHP Version": i[6],
			"OS": i[7],
			"Summary": i[8],
			"Assigned": i[9],
			"Description": i[10]})
	except Exception as e:
		error.append(i)

